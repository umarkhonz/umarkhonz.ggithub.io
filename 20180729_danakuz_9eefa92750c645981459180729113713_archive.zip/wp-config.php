<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'danak.uz');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'y:{&4=V^nb]]`:Z.h1+@dW#iBo:*|>B}U52;mZ*n[z>m;M.B-EdX]qc%#]./Z>pY');
define('SECURE_AUTH_KEY',  'Mrp{SE=ZSI?:lmjw>fdF@@o60&:&Zf#04Ui0@$.X;Ihm9,<2ZU[SI=1gY4HlTxkA');
define('LOGGED_IN_KEY',    'zWo@pq.K*H-z><A:;oS}#I .~6}`yAVkiE46q$o/~T<5~t<.$;arLucy7<}k+UZF');
define('NONCE_KEY',        '|RP_Z(_,%=3FPp5,EdfA_wyZex!;DG?oHl_MkcWOE^XrG[)A)NBqT_xI_}%O:}e[');
define('AUTH_SALT',        '#4I&;x-s%me?}?Axmyso8VF(hm-x)>8R| }z0rmgtK3iJbRCuXy28Y:G6`Qr0WQ%');
define('SECURE_AUTH_SALT', 'Yz{S[2[U;N%`q?$2d-:]1*YhQXymx$fP$,9>;p2g)&b}_s4Oya1_V8!oa>KY;a4A');
define('LOGGED_IN_SALT',   '@s!*QH|w(An-@qD%OLR(.Tl6b.kPHiYOa;sf[FJ&lZ-UGp*Gs0b&lxR6TY5wp6DP');
define('NONCE_SALT',       '@/Q1cbsuMu V^^k@Q,hUy7u&b -:#_J![<k~[aoFm=bnf(vjOV*^_/+79.v[ &Uq');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
